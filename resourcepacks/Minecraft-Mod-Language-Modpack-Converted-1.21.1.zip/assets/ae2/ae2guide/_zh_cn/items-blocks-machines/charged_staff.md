---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 充能手杖
  icon: charged_staff
  position: 410
categories:
- tools
item_ids:
- ae2:charged_staff
---

# 充能手杖

<ItemImage id="charged_staff" scale="4" />

充能手杖是在末端装有<ItemLink id="charged_certus_quartz_crystal" />的棍子。它能造成6点伤害，每次攻击消耗300AE。

可在<ItemLink id="charger" />中为其充能。

## 配方

<RecipeFor id="charged_staff" />
