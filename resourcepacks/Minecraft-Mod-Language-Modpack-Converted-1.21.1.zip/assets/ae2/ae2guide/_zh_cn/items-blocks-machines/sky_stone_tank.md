---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 陨石储罐
  icon: sky_stone_tank
  position: 310
categories:
- machines
item_ids:
- ae2:sky_stone_tank
---

# 陨石储罐

<BlockImage id="sky_stone_tank" scale="8" />

陨石储罐是能存储16桶流体的储罐。拆下捡起时不会保留内容物。大概就这样了。

## 配方

<RecipeFor id="sky_stone_tank" />
