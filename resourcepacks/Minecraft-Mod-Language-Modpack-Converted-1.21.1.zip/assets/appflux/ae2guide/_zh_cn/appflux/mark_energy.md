---
navigation:
  parent: appflux/appflux-index.md
  title: 标记FE
categories:
- flux tricks
---

# 如何在配置槽中标记FE

你可能会想用<ItemLink id="ae2:export_bus"/>输出能量，这就需要在其配置槽中标记FE。

以能量容器右击槽位即可标记FE。

![FE标记](../pic/fe_mark.png)
