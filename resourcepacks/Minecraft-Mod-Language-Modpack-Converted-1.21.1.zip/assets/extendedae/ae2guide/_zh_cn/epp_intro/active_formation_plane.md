---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME主动成型面板
    icon: extendedae:active_formation_plane
categories:
- extended devices
item_ids:
- extendedae:active_formation_plane
---

# ME主动成型面板

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_active_formation_plane.snbt"></ImportStructure>
</GameScene>

ME主动成型面板的性质与<ItemLink id="ae2:formation_plane" />相同，但可以主动放置方块和丢出物品。

无需为其设置子网络。它相当于不会输出至箱子、而是会放置方块的<ItemLink id="ae2:export_bus" />。
