---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: 水晶装配器
    icon: extendedae:crystal_assembler
categories:
- extended foundation
item_ids:
- extendedae:crystal_assembler
---

# 水晶装配器

<Row>
<BlockImage id="extendedae:crystal_assembler" scale="8"></BlockImage>
</Row>

扩展设备的配方太过复杂，工作台已经无法胜任了；其中的大多数需要水晶装配器才能合成。

**注意，屏幕一面不提供网络连接。**

它还可进行部分需在世界中进行的配方，如制造福鲁伊克斯水晶。
