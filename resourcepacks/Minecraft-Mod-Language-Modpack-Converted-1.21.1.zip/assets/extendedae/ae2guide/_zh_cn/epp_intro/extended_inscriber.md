---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: 扩展压印器
    icon: extendedae:ex_inscriber
categories:
- extended devices
item_ids:
- extendedae:ex_inscriber
---

# 扩展压印器

<Row gap="20">
<BlockImage id="extendedae:ex_inscriber" scale="8"></BlockImage>
</Row>

扩展压印器是高级版本的<ItemLink id="ae2:inscriber" />。

它能同时进行4个压印作业。

界面中有按钮可供调整槽位中物品的堆叠上限，和普通的压印器一致。

在与<ItemLink id="ae2:pattern_provider" />配合使用时，推荐将堆叠上限设为1，以避免出现问题。
