---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME扩展接口
    icon: extendedae:ex_interface
categories:
- extended devices
item_ids:
- extendedae:ex_interface
- extendedae:ex_interface_part
---

# ME扩展接口

<Row gap="20">
<BlockImage id="extendedae:ex_interface" scale="8"></BlockImage>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_ex_interface.snbt"></ImportStructure>
</GameScene>
</Row>

ME扩展接口是配置槽数更多的<ItemLink id="ae2:interface" />。

*我真的需要这个吗？*

![扩展接口界面](../pic/ei_gui.png)
