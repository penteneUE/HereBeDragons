---
navigation:
  title: 核源铁砧
  icon: "justdynathings:ferricore_anvil"
  position : 1
  parent: justdynathings:anvils.md
item_ids:
  - justdynathings:ferricore_anvil
---

# 核源铁砧

可以使用<ItemLink id="minecraft:iron_ingot"/>和<ItemLink id="justdirethings:ferricore_ingot"/>修复所有铁工具的砧。

<BlockImage id="justdynathings:ferricore_anvil" scale="4.0"/>

<RecipeFor id="justdynathings:ferricore_anvil" />