# mellow-shader

Simple gameplay-oriented Iris shaderpack meant for low-end computers. Mellow is vivid and colorful and aims to have a similar level of visibility to vanilla.

![sunset in a taiga biome](img/cover.png)

## Installation
Downloading directly from codeberg is usually not recommended, as the code is more likely to contain bugs.
Unless you have a good reason to download from here, you should go to [Modrinth](https://modrinth.com/shader/mellow) instead.

This shader requires [Iris](https://www.irisshaders.dev/) to function.
1. Click on the "More operations" button (with the three dots), located above the files, on the right.
2. Select "Download as ZIP"
3. Copy the file to your .minecraft/shaderpacks folder
4. Enable it in-game, in Options > Video Settings > Shader Packs

![](img/installation.png)

##  Features
- Bloom
- Wavy foliage & water
- Ambient & border fog
- "Realistic" clouds
- Lightmap based shadows
- Handheld lights
- Basic color grading (saturation, exposure, etc)
- Fully adjustable light colors

##   Compatibility
- Modern Nvidia, AMD and Intel gpus are supported on both Windows and Linux. Macs may or may not work.
- Please use the latest Iris version. Optifine has some small bugs, but it should also mostly work.
